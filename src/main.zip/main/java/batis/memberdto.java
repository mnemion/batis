package batis;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class memberdto {
	String  mno,mid,mpw,memail,mtel,marea,minter,mage,mdate;
}

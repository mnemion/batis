package batis;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class filevo {
	String fidx,fname;
}

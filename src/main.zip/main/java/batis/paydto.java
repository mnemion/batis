package batis;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class paydto {
	String goodcode, goodname, price, goodea, buyername, buyertel;
	String buyeremail, rec_post, rec_addr, rec_addr_dtc, point;
	String gopaymethod;
}
